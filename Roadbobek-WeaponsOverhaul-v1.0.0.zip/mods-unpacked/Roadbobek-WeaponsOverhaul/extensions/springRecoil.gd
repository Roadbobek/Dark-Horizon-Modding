extends "res://scripts/weapons/springRecoil.gd"

const MYMOD_LOG = "Roadbobek-WeaponsOverhaul"

var persistent_climb: Vector3 = Vector3.ZERO

var climb_per_shot: float = 0.020 # 0.015
var climb_recovery: float = 1.25 # 1.5


func _ready() -> void:
	ModLoaderLog.info("springRecoil.gd extension script ready", MYMOD_LOG)
	
	returnSpeed *= 0.8 # 0.75
	snappiness *= 1.2 # 1.3


func recoilFire() -> void:	
	var vertical_mult = 2.2
	var horizontal_mult = 1.0
	var backward_kick = 1.4
	
	var dynamic_z = recoil.z if recoil.z != 0.0 else recoil.y * 0.6
	
	targetRotation += Vector3(
		randf_range(recoil.x / 3.0, recoil.x * vertical_mult), 
		randf_range(-recoil.y * horizontal_mult, recoil.y * horizontal_mult), 
		randf_range(-dynamic_z * 2.0, dynamic_z * 2.0)
	)
	
	targetPosition += Vector3(
		randf_range(-positionRecoil.x * horizontal_mult, positionRecoil.x * horizontal_mult), 
		positionRecoil.y * vertical_mult, 
		positionRecoil.z * backward_kick
	)
	
	persistent_climb.x += climb_per_shot


func _process(delta: float) -> void:
	super(delta)
	
	persistent_climb = persistent_climb.lerp(Vector3.ZERO, climb_recovery * delta)
	
	rotation += persistent_climb
	
	
	

















#extends "res://scripts/weapons/springRecoil.gd"
#
#
#const MYMOD_LOG = "Roadbobek-WeaponsOverhaul"
#
#var persistent_climb: Vector3 = Vector3.ZERO
#
#var climb_per_shot: float = 0.015 
#var climb_recovery: float = 1.5 
#
#
#func _ready() -> void:
	#ModLoaderLog.info("springRecoil.gd extension script ready", MYMOD_LOG)
#
#
#func recoilFire() -> void:
	#super()
#
	#persistent_climb.x += climb_per_shot
#
#
#func _process(delta: float) -> void:
	#super(delta)
	#
	#persistent_climb = persistent_climb.lerp(Vector3.ZERO, climb_recovery * delta)
	#
	#rotation += persistent_climb
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	#extends "res://scripts/weapons/springRecoil.gd"
#
#
#const MYMOD_LOG = "Roadbobek-WeaponsOverhaul"
#
#
#func _ready() -> void:
	#ModLoaderLog.info("springRecoil.gd extension script ready", MYMOD_LOG)
	#returnSpeed *= 0.75
	#snappiness *= 1.3
#
#
#func recoilFire() -> void:
	#var vertical_mult = 2.2
	#var horizontal_mult = 1.2
	#var backward_kick = 1.8
	#
	#var dynamic_z = recoil.z if recoil.z != 0.0 else recoil.y * 0.6
	#
	#targetRotation += Vector3(
		#randf_range(recoil.x / 3.0, recoil.x * vertical_mult), 
		#randf_range(-recoil.y * horizontal_mult, recoil.y * horizontal_mult), 
		#randf_range(-dynamic_z * 2.0, dynamic_z * 2.0)
	#)
	#
	#targetPosition += Vector3(
		#randf_range(-positionRecoil.x * horizontal_mult, positionRecoil.x * horizontal_mult), 
		#positionRecoil.y * vertical_mult, 
		#positionRecoil.z * backward_kick
	#)
