extends "res://scripts/weapons/weaponNoise.gd"


const MYMOD_LOG = "Roadbobek-WeaponsOverhaul"

var mod_noise: FastNoiseLite = FastNoiseLite.new()
var mod_noise_speed: float = 0.0
var mod_bob_cycle: float = 0.0

var last_pos_offset: Vector3 = Vector3.ZERO
var last_rot_offset: Quaternion = Quaternion.IDENTITY


func _ready() -> void:
	super()
	
	ModLoaderLog.info("weaponNoise.gd extension script ready", MYMOD_LOG)
	mod_noise.seed = randi()
	mod_noise.frequency = 0.08 


func _physics_process(delta: float) -> void:
	if gun and last_pos_offset != Vector3.ZERO:
		gun.position -= last_pos_offset
		gun.quaternion = gun.quaternion * last_rot_offset.inverse()

	super(delta)

	if not gun:
		return

	var is_aiming = Input.is_action_pressed("mouse2")
	var is_moving = false
	if PlayerData.instance and "velocity" in PlayerData.instance:
		is_moving = PlayerData.instance.velocity.length() > 0.2

	var current_freq = 1.2 if is_moving else 0.35
	var current_amp = 0.02 if is_moving else 0.008
	
	if is_aiming:
		current_freq *= 0.4
		current_amp *= 0.15 

	mod_noise_speed += delta * current_freq * 4.0
	
	var sway_x = mod_noise.get_noise_2d(mod_noise_speed, 0.0) * current_amp
	var sway_y = mod_noise.get_noise_2d(0.0, mod_noise_speed) * current_amp
	var sway_z = mod_noise.get_noise_2d(mod_noise_speed, mod_noise_speed) * (current_amp * 1.1)

	var headbob = Vector3.ZERO
	if is_moving:
		mod_bob_cycle += delta * (11.0 if is_aiming else 8.5)
		var bob_intensity = 0.006 if not is_aiming else 0.001
		headbob.x = sin(mod_bob_cycle / 2.0) * bob_intensity
		headbob.y = abs(cos(mod_bob_cycle)) * bob_intensity

	var new_pos_offset = headbob + Vector3(sway_x * 0.25, sway_y * 0.25, 0.0)
	var new_rot_offset = Quaternion.from_euler(Vector3(sway_y, sway_x, sway_z))

	gun.position += new_pos_offset
	gun.quaternion = gun.quaternion * new_rot_offset

	last_pos_offset = new_pos_offset
	last_rot_offset = new_rot_offset
