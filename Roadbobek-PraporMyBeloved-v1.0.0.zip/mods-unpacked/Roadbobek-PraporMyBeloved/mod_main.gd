extends Node

const MOD_DIR = "Roadbobek-PraporMyBeloved/"
const MYMOD_LOG = "Roadbobek-PraporMyBeloved"

const FRAMEDPRAPOR_TSCN_PATH = "res://mods-unpacked/" + MOD_DIR + "FramedPrapor.tscn"
var framedprapor_tscn_packed = load(FRAMEDPRAPOR_TSCN_PATH)

func _init(modLoader = ModLoader):
	ModLoaderLog.info("Init", MYMOD_LOG)
	
	var new_framedprapor_instance = framedprapor_tscn_packed.instantiate()
	new_framedprapor_instance.position = Vector3(1.52, 1.502, 4.075)
	new_framedprapor_instance.rotation = Vector3(0, 1.5708, 3.1416)
	add_child(new_framedprapor_instance)
	

func _ready()->void:
	ModLoaderLog.info("Ready", MYMOD_LOG)
